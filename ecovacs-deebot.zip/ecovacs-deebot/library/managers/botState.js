'use strict';

const tools = require('../tools');
const mapTools = require('../mapTools');
const dictionary = require('../dictionary');
const { errorCodes } = require('../errorCodes.json');
const { eventCodes } = require('../eventCodes.json');
const {
    GetBatteryState,
    GetAdvancedMode,
    GetAngleFollow,
    GetAtmoLight,
    GetAtmoVolume,
    GetBorderSpin,
    GetBorderSwitch,
    GetCarpetInfo,
    GetCarpetPressure,
    GetChildLock,
    GetCrossMapBorderWarning,
    GetCutDirection,
    GetDrivingWheel,
    GetDryingDuration,
    GetEfficiencyMode,
    GetMic,
    GetMonitorAirState,
    GetMoveUpWarning,
    GetNetInfo,
    GetRelocationState,
    GetSafeProtect,
    GetSleepStatus,
    GetStationInfo,
    GetStationState,
    GetSweepMode,
    GetThreeModule,
    GetThreeModuleStatus,
    GetTotalStats,
    GetTrueDetect,
    GetVoiceAssistantState,
    GetVoiceSimple,
    GetVolume,
    GetWashInfo,
    GetWashInterval,
    GetWaterInfo,
    GetWorkMode,
} = require('../commands/info');
const { GetChargeState } = require('../commands/movement');
const {
    GetAutonomousClean,
    GetCleanCount,
    GetCleanPreference,
    GetContinuousCleaning,
    GetCustomAreaMode,
} = require('../commands/clean');

/**
 * @class BotState
 * Manages the internal state and status properties of the VacBot.
 */
class BotState {
    /**
     * @param {import('../vacBot')} bot - The VacBot instance.
     */
    constructor(bot) {
        this.bot = bot;

        // Status Properties
        this.batteryLevel = null;
        this.batteryIsLow = false;
        this.cleanReport = null;
        this.chargeStatus = null;
        this.chargeMode = null;
        this.cleanSpeed = null;
        this.waterLevel = null;
        this.waterboxInfo = null;
        this.moppingType = null;
        this.scrubbingType = null;
        this.sleepStatus = null;

        this.deebotPosition = {
            x: null,
            y: null,
            a: null,
            isInvalid: false,
            currentSpotAreaID: 'unknown',
            currentSpotAreaName: 'unknown',
            changeFlag: false
        };
        this.chargePosition = {
            x: null,
            y: null,
            a: null,
            changeFlag: false
        };

        this.cleanSum_totalSquareMeters = null;
        this.cleanSum_totalSeconds = null;
        this.cleanSum_totalNumber = null;

        this.cleanLog = [];
        this.cleanLog_lastImageUrl = null;
        this.cleanLog_lastTimestamp = null;
        this.cleanLog_lastTotalTime = null;
        this.cleanLog_lastTotalTimeString = null;
        this.cleanLog_lastSquareMeters = null;

        this.currentStats = {
            'cleanedArea': null,
            'cleanedSeconds': null,
            'cleanType': null
        };

        this.netInfoIP = null;
        this.netInfoWifiSSID = null;
        this.netInfoWifiSignal = null;
        this.netInfoMAC = null;

        this.firmwareVersion = null;
        this.timezone = null;
        this.OTA = null;
        this.sysinfo = null;

        this.stationState = null;
        this.stationInfo = null;
        this.washInterval = null;
        this.washInfo = null;

        this.advancedMode = null;
        this.autoEmpty = null;
        this.autoEmptyStatus = null;
        this.cleanCount = null;
        this.cleanPreference = null;
        this.workMode = null;
        this.workState = null;
        this.sweepMode = null;
        this.mopOnlyMode = null;
        this.borderSpin = null;
        this.borderSwitch = null;
        this.dusterRemind = null;
        this.carpetPressure = null;
        this.carpetInfo = null;
        this.block = null;
        this.blockTime = null;
        this.breakPoint = null;
        this.volume = null;
        this.voiceSimple = null;
        this.voiceAssistantState = null;

        this.trueDetect = null;
        this.avoidedObstacles = 0;
        this.obstacleTypes = null;
        this.aiCleanItemState = null;

        this.crossMapBorderWarning = null;
        this.cutDirection = null;
        this.moveupWarning = null;
        this.safeProtect = null;

        this.evt = null;
        this.currentTask = {
            'type': 'none',
            'triggerType': 'none',
            'failed': false,
            'stopReason': 'none'
        };
        this.liveLaunchPwdState = null;

        this.airQuality = null;
        this.aiBlockPlate = null;
        this.airbotAutoModel = null;
        this.angleFollow = null;
        this.angleWakeup = null;
        this.atmoLightIntensity = null;
        this.atmoVolume = null;
        this.areaPoint = null;
        this.autonomousClean = null;
        this.bluetoothSpeaker = null;
        this.childLock = null;
        this.humanoidFollow = null;
        this.mic = null;
        this.monitorAirState = null;
        this.threeModule = null;
        this.threeModuleStatus = null;
        this.dmodule = null;
        this.efficiency = null;
        this.dryingDuration = null;
        this.airDryingStatus = null;
        this.relocationStatus = null;
        this.relocationState = null;
        this.customizedScenarioCleaning = null;

        this.errorCode = '0';
        this.errorDescription = '';
        this.schedule = [];
    }

    /**
     * Handle the payload of the `CleanInfo` response/message
     * (e.g. charge status, clean status and the last area values)
     * @param {Object} payload
     */
    handleCleanInfo(payload) {
        this.bot.currentSpotAreas = '';
        this.bot.currentCustomAreaValues = '';
        if (payload['state'] === 'clean') {
            let type = payload['cleanState']['type'];
            const content = payload['cleanState']['content'];
            if (typeof content === 'object') {
                type = content['type'];
            }
            if (payload['cleanState']['motionState'] === 'working') {
                this.cleanReport = dictionary.CLEAN_MODE_FROM_ECOVACS[type];
            } else {
                this.cleanReport = dictionary.CLEAN_MODE_FROM_ECOVACS[payload['cleanState']['motionState']];
            }
            if ((type === 'spotArea') || (type === 'customArea')) {
                let areaValues;
                if (typeof content === `object`) {
                    areaValues = content['value'];
                } else {
                    areaValues = content;
                }
                if (type === 'customArea') {
                    if (typeof content === 'object') {
                        const doNotClean = content['donotClean'];
                        if ((doNotClean === 1) || (areaValues.split(',').length === 2)) {
                            // Controlled via Video Manager
                            this.cleanReport = 'setLocation';
                        }
                    }
                    this.bot.currentCustomAreaValues = areaValues;
                } else if (type === 'spotArea') {
                    this.bot.currentSpotAreas = areaValues;
                }
            }
        } else if (payload['trigger'] === 'alert') {
            this.cleanReport = 'alert';
        } else {
            this.cleanReport = dictionary.CLEAN_MODE_FROM_ECOVACS[payload['state']];
            if (dictionary.CLEAN_MODE_FROM_ECOVACS[payload['state']] === 'returning') {
                // set charge state on returning to dock
                const chargeStatus = dictionary.CLEAN_MODE_FROM_ECOVACS[payload['state']];
                if (chargeStatus) {
                    this.chargeStatus = chargeStatus;
                }
            } else if (dictionary.CLEAN_MODE_FROM_ECOVACS[payload['state']] === 'idle') {
                // when clean state = idle the bot can be charging on the dock or the return to dock has been canceled
                // if this is not run, the status when canceling the return stays on 'returning'
                this.bot.run('GetChargeState');
            }
        }
    }

    /**
     * Handle the payload of the `StationState` response/message
     * @param {Object} payload
     */
    handleStationState(payload) {
        this.stationState = new GetStationState().parseResponse(payload);
    }

    /**
     * Handle the payload of the `StationInfo` response/message
     * @param {Object} payload
     */
    handleStationInfo(payload) {
        this.stationInfo = new GetStationInfo().parseResponse(payload);
    }

    /**
     * Handle the payload of the `WashInterval` response/message
     * @param {Object} payload
     */
    handleWashInterval(payload) {
        this.washInterval = new GetWashInterval().parseResponse(payload);
    }

    /**
     * Handle the payload of the `WashInfo` response/message
     * @param {Object} payload
     */
    handleWashInfo(payload) {
        this.washInfo = new GetWashInfo().parseResponse(payload);
    }

    /**
     * Handle the payload of the `Battery` response/message (battery level)
     * Parsing is delegated to `GetBatteryState.parse()` to ensure a single source
     * of truth shared with the `runAsync()` / `parseResponse()` path.
     * @param {Object} payload
     */
    handleBattery(payload) {
        const result = GetBatteryState.parse(payload);
        this.batteryLevel = result.level;
        this.batteryIsLow = result.isLow;
    }

    /**
     * Handle the payload of the `Pos` response/message
     * (vacuum position and charger resp. charge position)
     * @param {Object} payload
     */
    handlePos(payload) {
        // is only available in some DeebotPosition messages (e.g. on start cleaning)
        // there can be more than one charging station only handles first charging station
        const chargePos = payload['chargePos'];
        if (chargePos) {
            // check if position changed
            const changed = (
                chargePos[0]['x'] !== this.chargePosition.x ||
                chargePos[0]['y'] !== this.chargePosition.y ||
                chargePos[0]['a'] !== this.chargePosition.a
            );
            if (changed) {
                this.chargePosition = {
                    x: chargePos[0]['x'],
                    y: chargePos[0]['y'],
                    a: chargePos[0]['a'],
                    changeFlag: true
                };
            }
        }
        // as deebotPos and chargePos can also appear in other messages (CleanReport)
        // the handling should be extracted to a separate function
        const deebotPos = payload['deebotPos'];
        if (typeof deebotPos === 'object') {
            // check if position changed or currentSpotAreaID is 'unknown'
            const changed = (
                deebotPos['x'] !== this.deebotPosition.x ||
                deebotPos['y'] !== this.deebotPosition.y ||
                deebotPos['a'] !== this.deebotPosition.a ||
                deebotPos['invalid'] !== this.deebotPosition.isInvalid ||
                this.deebotPosition.currentSpotAreaID === 'unknown'
            );
            if (changed) {
                const posX = Number(deebotPos['x']);
                const posY = Number(deebotPos['y']);
                const currentSpotAreaID = mapTools.getCurrentSpotAreaID(
                    posX, posY, this.bot.mapSpotAreaInfos[this.bot.currentMapMID]
                );
                const isInvalid = Number(deebotPos['invalid']) === 1;
                let distanceToChargingStation = null;
                if (this.chargePosition) {
                    const pos = deebotPos['x'] + ',' + deebotPos['y'];
                    const chargePos = this.chargePosition.x + ',' + this.chargePosition.y;
                    distanceToChargingStation = mapTools.getDistanceToChargingStation(pos, chargePos);
                }
                this.deebotPosition = {
                    x: deebotPos['x'],
                    y: deebotPos['y'],
                    a: deebotPos['a'],
                    isInvalid: isInvalid,
                    currentSpotAreaID: currentSpotAreaID,
                    currentSpotAreaName: this.bot.getSpotAreaName(currentSpotAreaID),
                    changeFlag: true,
                    distanceToChargingStation: distanceToChargingStation
                };
            }
        }
    }

    /**
     * TODO: Find out the value of the 'Evt' message
     * @param {Object} payload - The payload of the event.
     */
    handleEvt(payload) {
        const code = payload['code'];
        if (eventCodes.hasOwnProperty(code)) {
            tools.envLogWarn(`Evt code: '${eventCodes[code]}'`);
            this.evt = {
                code: code,
                event: eventCodes[code]
            };
        } else {
            const eventMessage = `Unhandled Evt code: '${code}'`;
            tools.envLogWarn(eventMessage);
            this.evt = {
                code: code,
                event: eventMessage
            };
        }
    }

    /**
     * Handle the payload of the `Speed` response/message (vacuum power resp. suction power)
     * @param {Object} payload
     */
    handleSpeed(payload) {
        const speed = payload['speed'];
        this.cleanSpeed = speed;
        if (!this.bot.isPlatformTypeAirbot()) {
            this.cleanSpeed = dictionary.CLEAN_SPEED_FROM_ECOVACS[speed];
        }
    }

    /**
     * Handle the payload of the `NetInfo` response/message
     * (network addresses and Wi-Fi status)
     * @param {Object} payload
     */
    handleNetInfo(payload) {
        const result = new GetNetInfo().parseResponse(payload);
        this.netInfoIP = result.ip;
        this.netInfoWifiSSID = result.wifiSSID;
        this.netInfoWifiSignal = result.wifiSignal;
        this.netInfoMAC = result.mac;
    }

    /**
     * Handle the payload of the `BorderSwitch` response/message
     * @param {Object} payload
     */
    handleBorderSwitch(payload) {
        this.borderSwitch = new GetBorderSwitch().parseResponse(payload);
    }

    /**
     * Handle the payload of the `CrossMapBorderWarning` response/message
     * @param {Object} payload
     */
    handleCrossMapBorderWarning(payload) {
        this.crossMapBorderWarning = new GetCrossMapBorderWarning().parseResponse(payload);
    }

    /**
     * Handle the payload of the `CutDirection` response/message
     * @param {Object} payload
     */
    handleCutDirection(payload) {
        this.cutDirection = new GetCutDirection().parseResponse(payload);
    }

    /**
     * Handle the payload of the `MoveupWarning` response/message
     * @param {Object} payload
     */
    handleMoveupWarning(payload) {
        this.moveupWarning = new GetMoveUpWarning().parseResponse(payload);
    }

    /**
     * Handle the payload of the `SafeProtect` response/message
     * @param {Object} payload
     */
    handleSafeProtect(payload) {
        this.safeProtect = new GetSafeProtect().parseResponse(payload);
    }

    /**
     * Handle the payload of the `WorkState` response/message
     * @param {Object} payload
     */
    handleWorkState(payload) {
        this.workState = {
            robot: payload['robotState'] ? payload['robotState']['state'] : null,
            station: payload['stationState'] ? payload['stationState']['state'] : null,
            paused: Boolean(payload['paused'])
        };
    }

    /**
     * Handle the payload of the `WaterInfo` response/message
     * (water level and water box status)
     * @param {Object} payload
     */
    handleWaterInfo(payload) {
        const result = new GetWaterInfo().parseResponse(payload);
        this.waterLevel = result.waterLevel;
        this.waterboxInfo = result.waterboxInfo;
        // 1 = Regular, 2 = OZMO Pro
        if (result.moppingType !== undefined) {
            this.moppingType = result.moppingType;
        }
        // 1 = Quick scrubbing, 2 = Deep scrubbing
        if (result.scrubbingType !== undefined) {
            this.scrubbingType = result.scrubbingType;
        }
    }

    /**
     * Handle the payload of the `AICleanItemState` response/message
     * Particle Removal and Pet Poop Avoidance mode (e.g. X1)
     * @param {Object} payload
     */
    handleAICleanItemState(payload) {
        if (payload.hasOwnProperty('items')) {
            const items = payload.items;
            const particleRemoval = Boolean(items[0].state);
            const petPoopPrevention = Boolean(items[2].state);
            this.aiCleanItemState = {
                items: items,
                particleRemoval: particleRemoval,
                petPoopPrevention: petPoopPrevention
            };
        }
    }

    /**
     * Handle the payload of the `AirDring` (sic) response/message (air drying status)
     * Seems to work for yeedi only
     * See `StationState` for Deebot models
     * @param {Object} payload
     */
    handleAirDryingState(payload) {
        let airDryingStatus = null;
        const status = parseInt(payload['status']);
        if (status === 1) {
            airDryingStatus = 'airdrying';
        } else if (status === 2) {
            airDryingStatus = 'idle';
        }
        if (airDryingStatus) {
            this.airDryingStatus = airDryingStatus;
        }
    }

    /**
     * Handle the payload of the `DryingDuration` response/message
     * @param {Object} payload
     */
    handleDryingDuration(payload) {
        this.dryingDuration = new GetDryingDuration().parseResponse(payload);
    }

    /**
     * Handle the payload of the `BorderSpin` response/message
     * @param {Object} payload
     */
    handleBorderSpin(payload) {
        this.borderSpin = new GetBorderSpin().parseResponse(payload);
    }

    /**
     * Handle the payload of the `WorkMode` response/message
     * ('Work Mode', 'Cleaning Mode')
     * vacuum and mop = 0
     * vacuum only = 1
     * mop only = 2
     * mop after vacuum = 3
     * @param {Object} payload
     */
    handleWorkMode(payload) {
        this.workMode = new GetWorkMode().parseResponse(payload);
    }

    /**
     * Handle the payload of the `CustomAreaMode` response/message
     * `Mopping Mode`/`Cleaning efficiency` is taken from the `CustomAreaMode` message
     * not from the `SweepMode` message
     * @param {Object} payload
     */
    handleCustomAreaMode(payload) {
        this.sweepMode = new GetCustomAreaMode().parseResponse(payload);
    }

    /**
     * Handle the payload of the `SweepMode` response/message
     * "Mop-Only" is taken from the SweepMode message
     * @param {Object} payload
     */
    handleSweepMode(payload) {
        this.mopOnlyMode = new GetSweepMode().parseResponse(payload);
    }

    /**
     * Handle the payload of the `ChargeState` response/message (charge status)
     * @param {Object} payload
     */
    handleChargeState(payload) {
        const result = new GetChargeState().parseResponse(payload);
        this.chargeStatus = result.chargeStatus;
        this.chargeMode = result.chargeMode;
    }

    /**
     * Handle the payload of the `Sleep` response/message (sleep status)
     * @param {Object} payload
     */
    handleSleepStatus(payload) {
        this.sleepStatus = new GetSleepStatus().parseResponse(payload);
    }

    /**
     * Handle the payload of the `CleanLogs` response/message
     * @param {Object} payload
     */
    handleCleanLogs(payload) {
        let logs = [];
        this.cleanLog = [];
        if (payload.hasOwnProperty('logs')) {
            logs = payload['logs'];
        } else if (payload.hasOwnProperty('log')) {
            logs = payload['log'];
        } else if (payload.hasOwnProperty('data')) {
            logs = payload['data'];
        }

        for (const logIndex in logs) {
            if (!logs.hasOwnProperty(logIndex)) {
                continue;
            }
            const logEntry = logs[logIndex];
            if (this.cleanLog[logEntry['id']]) {
                continue;
            }
            const squareMeters = parseInt(logEntry['area']);
            const timestamp = Number(logEntry['ts']);
            const date = new Date(timestamp * 1000);
            const len = parseInt(logEntry['last']);
            const totalTimeString = tools.getTimeStringFormatted(len);
            const imageUrl = logEntry['imageUrl'];
            if ((this.cleanLog_lastTimestamp < timestamp) || (!this.cleanLog_lastTimestamp)) {
                this.cleanLog_lastImageUrl = imageUrl;
                this.cleanLog_lastTimestamp = timestamp;
                this.cleanLog_lastSquareMeters = squareMeters;
                this.cleanLog_lastTotalTime = len;
                this.cleanLog_lastTotalTimeString = totalTimeString;
            }
            this.cleanLog[logEntry['id']] = {
                'squareMeters': squareMeters,
                'timestamp': timestamp,
                'date': date,
                'lastTime': len,
                'totalTime': len,
                'totalTimeFormatted': totalTimeString,
                'imageUrl': imageUrl,
                'type': logEntry['type'],
                'stopReason': logEntry['stopReason']
            };
        }
    }

    /**
     * Emit all CleanLog-related events.
     * Consolidates the emit logic for both code paths
     * (MQTT response via `lg/log.do` and REST API via `dln/api/log/clean_result/list`)
     */
    emitCleanLogEvents() {
        const cleanLog = [];
        for (const i in this.cleanLog) {
            if (this.cleanLog.hasOwnProperty(i)) {
                cleanLog.push(this.cleanLog[i]);
            }
        }
        this.bot.ecovacs.emitMessage('CleanLog', cleanLog);
        this.bot.ecovacs.emitMessage('LastCleanLogs', {
            'timestamp': this.cleanLog_lastTimestamp,
            'squareMeters': this.cleanLog_lastSquareMeters,
            'totalTime': this.cleanLog_lastTotalTime,
            'totalTimeFormatted': this.cleanLog_lastTotalTimeString,
            'imageUrl': this.cleanLog_lastImageUrl
        });
    }

    /**
     * Handle the payload of the `TotalStats` response/message
     * @param {Object} payload
     */
    handleTotalStats(payload) {
        const result = new GetTotalStats().parseResponse(payload);
        this.cleanSum_totalSquareMeters = result.totalSquareMeters;
        this.cleanSum_totalSeconds = result.totalSeconds;
        this.cleanSum_totalNumber = result.totalNumber;
    }

    /**
     * Handle the payload of the `RelocationState` response/message
     * @param {Object} payload
     */
    handleRelocationState(payload) {
        const result = new GetRelocationState().parseResponse(payload);
        this.relocationStatus = result.status;
        this.relocationState = result.state;
    }

    /**
     * Handle the payload of the `Volume` response/message
     * @param {Object} payload
     */
    handleVolume(payload) {
        this.volume = new GetVolume().parseResponse(payload);
    }

    /**
     * Handle the payload of the `BreakPoint` response/message
     * @param {Object} payload
     */
    handleBreakPoint(payload) {
        this.breakPoint = new GetContinuousCleaning().parseResponse(payload);
    }

    /**
     * Handle the payload of the `Block` response/message
     * @param {Object} payload
     */
    handleBlock(payload) {
        this.block = payload['enable'];
        if (payload.hasOwnProperty('start')) {
            this.blockTime = {
                'from': payload['start'],
                'to': payload['end']
            };
        }
    }

    /**
     * Handle the payload of the 'AutoEmpty' response/message
     * @param {Object} payload
     */
    handleAutoEmpty(payload) {
        this.autoEmpty = payload['enable'];
        if (payload.hasOwnProperty('status')) {
            // 0 disabled
            // 1 enabled
            // 2 dust bag not full
            // 5 dust bag need to be changed
            this.autoEmptyStatus = payload['status'];
        }
    }

    /**
     * Handle the payload of the 'AdvancedMode' response/message
     * @param {Object} payload
     */
    handleAdvancedMode(payload) {
        this.advancedMode = new GetAdvancedMode().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'TrueDetect' response/message
     * @param {Object} payload
     */
    handleTrueDetect(payload) {
        this.trueDetect = new GetTrueDetect().parseResponse(payload);
    }

    handleRecognization(payload) {
        this.trueDetect = payload['state'];
        if (payload) {
            tools.envLogInfo(`payload for Recognization message: ${JSON.stringify(payload)}`);
        }
    }

    /**
     * Handle the payload of the 'CleanCount' response/message
     * @param {Object} payload
     */
    handleCleanCount(payload) {
        this.cleanCount = new GetCleanCount().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'DusterRemind' response/message
     * @param {Object} payload
     */
    handleDusterRemind(payload) {
        this.dusterRemind = {
            enabled: payload['enable'],
            period: payload['period']
        };
    }

    /**
     * Handle the payload of the 'CarpertPressure' (sic) response/message
     * 'Auto-Boost Suction'
     * @param {Object} payload
     */
    handleCarpetPressure(payload) {
        this.carpetPressure = new GetCarpetPressure().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'CarpetInfo' response/message
     * 'Carpet cleaning strategy'
     * @param {Object} payload
     */
    handleCarpetInfo(payload) {
        this.carpetInfo = new GetCarpetInfo().parseResponse(payload);
    }

    /**
     * Handle the payload of the `CleanPreference` response/message
     * @param {Object} payload
     */
    handleCleanPreference(payload) {
        this.cleanPreference = new GetCleanPreference().parseResponse(payload);
    }

    /**
     * Handle the payload of the `LiveLaunchPwdState` response/message
     * @param {Object} payload
     */
    handleLiveLaunchPwdState(payload) {
        this.liveLaunchPwdState = {
            state: payload.state,
            hasPwd: payload.hasPwd
        };
    }

    /**
     * Handle the payload of the `WiFiList` response/message
     * @param {Object} payload
     */
    handleWiFiList(payload) {
        if (payload.list) {
            tools.envLogInfo('Configured networks:');
            payload.list.forEach((network) => {
                tools.envLogInfo('- ' + network);
            });
        }
        tools.envLogInfo(`mac address: ${payload.mac}`);
    }

    /**
     * Handle the payload of the `OverTheAirUpdate` response/message
     * @param {Object} payload
     */
    handleOverTheAirUpdate(payload) {
        this.OTA = payload;
        tools.envLogInfo(`ota status: ${JSON.stringify(payload)}`);
    }

    /**
     * Handle the payload of the `TimeZone` response/message
     * @param {Object} payload
     */
    handleTimeZone(payload) {
        const sign = payload.tzm >= 0 ? '+' : '-';
        this.timezone = `GMT${sign}${Math.abs(payload.tzm) / 60}:00`;
    }

    /**
     * Handle the payload of the 'Stats' response/message
     * @param {Object} payload
     */
    handleStats(payload) {
        this.currentStats = {
            'cleanedArea': payload['area'],
            'cleanedSeconds': payload['time'],
            'cleanType': payload['type']
        };
        if (payload.hasOwnProperty('avoidCount')) {
            if (this.avoidedObstacles !== payload['avoidCount']) {
                tools.envLogNotice('whoops ... there might be something in the way');
            }
            this.avoidedObstacles = payload['avoidCount'];
        }
        if (payload.hasOwnProperty('aiopen') && Number(payload['aiopen']) === 1) {
            if (JSON.stringify(this.obstacleTypes) !== JSON.stringify(payload['aitypes'])) {
                tools.envLogNotice('whoops ... there might be something new blocking my way');
            }
            this.obstacleTypes = payload['aitypes'];
        }
    }

    /**
     * Handle the payload of the 'Sched' response/message (Schedule)
     * @param {Object} payload
     */
    handleSched(payload) {
        this.schedule = [];
        for (let c = 0; c < payload.length; c++) {
            const resultData = payload[c];
            if (resultData.repeat !== undefined) {
                const cleanCtl = {
                    'type': 'auto'
                };
                if (resultData.hasOwnProperty('content') && resultData.content.hasOwnProperty('jsonStr')) {
                    const json = JSON.parse(resultData.content.jsonStr);
                    Object.assign(cleanCtl, {
                        'type': json.type
                    });
                    if (cleanCtl.type === 'spotArea') {
                        Object.assign(cleanCtl, {
                            'spotAreas': json.content
                        });
                    }
                }
                const onlyOnce = Number(resultData.repeat) === 0;
                const weekdays = resultData.repeat.split('');
                const weekdaysObj = {
                    'Mon': Boolean(Number(weekdays[1])),
                    'Tue': Boolean(Number(weekdays[2])),
                    'Wed': Boolean(Number(weekdays[3])),
                    'Thu': Boolean(Number(weekdays[4])),
                    'Fri': Boolean(Number(weekdays[5])),
                    'Sat': Boolean(Number(weekdays[6])),
                    'Sun': Boolean(Number(weekdays[0]))
                };
                const object = {
                    'sid': resultData.sid,
                    'cleanCmd': cleanCtl,
                    'content': resultData.content,
                    'enabled': Boolean(Number(resultData.enable)),
                    'onlyOnce': onlyOnce,
                    'weekdays': weekdaysObj,
                    'hour': resultData.hour,
                    'minute': resultData.minute,
                    'mapID': resultData.mid
                };
                this.schedule.push(object);
            }
        }
    }

    /**
     * Handle the payload of the 'QuickCommand' response/message
     * @param {Object} payload - The payload containing the customized scenario cleaning.
     */
    handleQuickCommand(payload) {
        this.customizedScenarioCleaning = payload;
    }

    /**
     * Handle the payload of the 'Error' response/message
     * @param {Object} payload
     */
    handleResponseError(payload) {
        this.bot.errorCode = payload['code'].toString();
        if (this.bot.errorCode === '') {
            this.bot.errorCode = '-3';
        }
        // known errorCode from library
        if (errorCodes[this.bot.errorCode]) {
            this.bot.errorDescription = errorCodes[this.bot.errorCode];
            // Request error
            if (this.bot.errorCode === '1') {
                this.bot.errorDescription = this.bot.errorDescription + ': ' + payload.error;
            }
        } else {
            this.bot.errorDescription = `unknown errorCode: ${this.bot.errorCode}`;
        }
        if (this.bot.errorCode !== '0') {
            tools.envLogWarn(`errorCode: ${this.bot.errorCode}`);
            tools.envLogWarn(`errorDescription: ${this.bot.errorDescription}`);
        }
    }

    /**
     * Handles the air quality data received from the payload.
     * 'Indoor' Air Quality
     * @param {object} payload - The air quality data payload.
     */
    handleAirQuality(payload) {
        if (!payload['pm25']) {
            // Handle 'onJCYAirQuality' event for Z1 AirQuality Monitor
            const keys = Object.keys(payload);
            payload = payload[keys[0]];
        }
        this.airQuality = {
            'particulateMatter25': payload['pm25'],
            'particulateMatter10': payload['pm10'],
            'airQualityIndex': payload['aq'],
            'volatileOrganicCompounds': payload['voc'],
            'temperature': payload['tem'],
            'humidity': payload['hum']
        };
        // The Z1 AirQuality Monitor also has
        // another 'voc' (Volatile Organic Compounds) value
        if (payload['voc_num'] !== undefined) {
            Object.assign(this.airQuality, {
                'volatileOrganicCompounds_parts': payload['voc_num']
            });
        }
        // Note: There's also has another pm10 value ('pm_10')
        // but it seems that there is no additional benefit
    }

    /**
     * Handle the payload of the 'MonitorAirState' response/message
     * @param {Object} payload
     */
    handleMonitorAirState(payload) {
        this.monitorAirState = new GetMonitorAirState().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'AngleFollow' response/message
     * 'Face to Me' option
     * @param {Object} payload
     */
    handleAngleFollow(payload) {
        this.angleFollow = new GetAngleFollow().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'AngleWakeup' response/message
     * @param {Object} payload
     */
    handleAngleWakeup(payload) {
        this.angleWakeup = payload['on'];
    }

    /**
     * Handle the payload of the 'Mic' response/message
     * 'Microphone'
     * @param {Object} payload
     */
    handleMic(payload) {
        this.mic = new GetMic().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'VoiceSimple' response/message
     * 'Working Status Voice Report'
     * @param {Object} payload
     */
    handleVoiceSimple(payload) {
        this.voiceSimple = new GetVoiceSimple().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'DrivingWheel' response/message
     * @param {Object} payload
     */
    handleDrivingWheel(payload) {
        this.drivingWheel = new GetDrivingWheel().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'ChildLock' response/message
     * 'Child Lock'
     * @param {Object} payload
     */
    handleChildLock(payload) {
        this.childLock = new GetChildLock().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'VoiceAssistantState' response/message
     * 'YIKO Voice Assistant'
     * @param {Object} payload
     */
    handleVoiceAssistantState(payload) {
        this.voiceAssistantState = new GetVoiceAssistantState().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'HumanoidFollow' response/message
     * 'Lab Features' => 'Follow Me'
     * @param {Object} payload
     */
    handleHumanoidFollow(payload) {
        this.humanoidFollow = {
            'video': payload['video'],
            'yiko': payload['yiko']
        };
    }

    /**
     * Handle the payload of the 'AutonomousClean' response/message
     * 'Self-linked Purification'
     * @param {Object} payload
     */
    handleAutonomousClean(payload) {
        this.autonomousClean = new GetAutonomousClean().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'AirbotAutoMode' response/message
     * 'Linked Purification' (linked to Air Quality Monitor)
     * @param {Object} payload
     */
    handleAirbotAutoModel(payload) {
        if (payload['aq'] && payload['aq']['aqStart'] && payload['aq']['aqEnd']) {
            this.airbotAutoModel = {
                'enable': payload['enable'],
                'trigger': payload['trigger'],
                'aq': {
                    'aqStart': payload['aq']['aqStart'],
                    'aqEnd': payload['aq']['aqEnd']
                }
            };
        }
    }

    /**
     * Handle the payload of the 'BlueSpeaker' response/message
     * 'Bluetooth Speaker'
     * @param {Object} payload
     */
    handleBlueSpeaker(payload) {
        this.bluetoothSpeaker = {
            'enable': payload['enable'],
            'time': payload['time'],
            'name': payload['name']
        };
    }

    /**
     * Handle the payload of the 'Efficiency' response/message
     * Always seems to return a value of 0
     * @param {Object} payload
     */
    handleEfficiency(payload) {
        this.efficiency = new GetEfficiencyMode().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'AtmoLight' response/message
     * 'Light Brightness'
     * @param {Object} payload
     */
    handleAtmoLight(payload) {
        this.atmoLightIntensity = new GetAtmoLight().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'AtmoVolume' response/message
     * 'Volume'
     * @param {Object} payload
     */
    handleAtmoVolume(payload) {
        this.atmoVolume = new GetAtmoVolume().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'ThreeModule' (UV, Humidifier, AirFreshener) response/message
     * It contains the current level set for Air Freshening and Humidification
     * @param {Object} payload
     */
    handleThreeModule(payload) {
        this.threeModule = new GetThreeModule().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'ThreeModuleStatus' (UV, Humidifier, AirFreshener) response/message
     * It contains the working status of these modules
     * @param {Object} payload
     */
    handleThreeModuleStatus(payload) {
        this.threeModuleStatus = new GetThreeModuleStatus().parseResponse(payload);
    }

    /**
     * Handle the payload of the 'AreaPoint' response/message
     * @param {Object} payload
     */
    handleAreaPoint(payload) {
        this.areaPoint = payload;
    }

    /**
     * Handle the payload of the 'AiBlockPlate' response/message
     * @param {Object} payload
     */
    handleAiBlockPlate(payload) {
        this.aiBlockPlate = payload['on'];
    }

    /**
     * Handle the payload of the '(FwBuryPoint-)Sysinfo' response/message
     * @param {Object} payload
     */
    handleSysinfo(payload) {
        try {
            const event = payload[0];
            this.sysinfo = {
                'load': event['uptime'].substring(event['uptime'].indexOf('average') + 9),
                'uptime': event['uptime'].substring(event['uptime'].indexOf('up') + 3).substr(0, event['uptime'].substring(event['uptime'].indexOf('up') + 3).indexOf('users')).substr(0, event['uptime'].substring(event['uptime'].indexOf('up') + 3).substr(0, event['uptime'].substring(event['uptime'].indexOf('up') + 3).indexOf('users')).lastIndexOf(',')),
                'signal': event['signal'],
                'meminfo': event['meminfo'],
                'pos': event['pos']
            };
        } catch (e) {
            tools.envLogWarn(`error handling System information: ${e.toString()}`);
        }
    }

    /**
     * Handle the payload/state of the current task.
     * @param {string} type - The type of task.
     * @param {Object} payload - The task payload.
     */
    handleTask(type, payload) {
        const stopReason = this.currentTask.stopReason;
        this.currentTask = {
            'type': type,
            'triggerType': payload.hasOwnProperty('triggerType') ? payload['triggerType'] : 'none',
            'failed': false,
            'stopReason': stopReason
        };
        if (payload.hasOwnProperty('go_fail')) {
            this.currentTask.failed = true;
        }
        if (payload.hasOwnProperty('stopReason')) {
            this.currentTask.stopReason = payload['stopReason'];
        }
    }

    /**
     * Handle the payload of the `DModule` response/message
     * @param {Object} payload
     */
    handleDModule(payload) {
        this.dmodule = payload;
    }

    /**
     * Get the correct command name for obstacle detection based on device platform type.
     * @returns {string}
     */
    getCmdForObstacleDetection() {
        if ((this.bot.getPlatformType() === 'T8') || (this.bot.getPlatformType() === 'T9')) {
            return "Recognization";
        } else {
            return "TrueDetect";
        }
    }
}

module.exports = BotState;
