'use strict';

function isExternSettingsFileAvailable() {
    try {
        require.resolve('./../../deebotExampleSettings');
        return true;
    } catch {
        return false;
    }
}

function getSettingsFile() {
    if (isExternSettingsFileAvailable()) {
        return require('./../../deebotExampleSettings');
    }
    return require('./settings');
}

function dumpSomeVacbotData(vacbot, api) {
    console.log(`- Name: ${vacbot.getName()}`);
    console.log(`- Model: ${vacbot.deviceModel}`);
    console.log(`- Device type: ${vacbot.getDeviceType()}`);
    console.log(`- Image url: ${vacbot.deviceImageURL}`);
    console.log(`- Is fully supported model: ${vacbot.isSupportedDevice()}`);
    console.log(`- Is a at least partly supported model: ${vacbot.isKnownDevice()}`);
    console.log(`- Is legacy model: ${vacbot.isLegacyModel()}`);
    console.log(`- Is 950 type model: ${vacbot.is950type()}`);
    console.log(`- V2 commands are implemented: ${vacbot.is950type_V2()}`);
    console.log(`- Communication protocol: ${vacbot.getProtocol()}`);
    console.log(`- Mapping capabilities: ${vacbot.hasMappingCapabilities()}`);
    console.log(`- Edge cleaning mode: ${vacbot.hasEdgeCleaningMode()}`);
    console.log(`- Spot cleaning mode: ${vacbot.hasSpotCleaningMode()}`);
    console.log(`- Spot area cleaning mode: ${vacbot.hasSpotAreaCleaningMode()}`);
    console.log(`- Custom area cleaning mode: ${vacbot.hasCustomAreaCleaningMode()}`);
    console.log(`- Mopping system: ${vacbot.hasMoppingSystem()}`);
    console.log(`- Voice reports: ${vacbot.hasVoiceReports()}`);
    console.log(`- Auto empty station: ${vacbot.hasAutoEmptyStation()}`);
    console.log(`- Optional auto empty station: ${vacbot.hasAutoEmptyStationOptional()}`);
    console.log(`- Canvas module available: ${api.getCanvasModuleIsAvailable()}`);
    console.log(`- Using country: ${api.getCountryName()}`);
    console.log(`- Using continent code: ${api.getContinent()}`);
}

module.exports.getSettingsFile = getSettingsFile;
module.exports.dumpSomeVacbotData = dumpSomeVacbotData;
