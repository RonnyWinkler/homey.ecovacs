export = BotState;
/**
 * @class BotState
 * Manages the internal state and status properties of the VacBot.
 */
declare class BotState {
    /**
     * @param {import('../vacBot')} bot - The VacBot instance.
     */
    constructor(bot: typeof import("../ecovacsDevice"));
    bot: typeof import("../ecovacsDevice");
    batteryLevel: number | null;
    batteryIsLow: boolean;
    cleanReport: any;
    chargeStatus: any;
    chargeMode: string | null;
    cleanSpeed: any;
    waterLevel: number | null;
    waterboxInfo: number | null;
    moppingType: number | null;
    scrubbingType: number | null;
    sleepStatus: boolean | null;
    deebotPosition: {
        x: null;
        y: null;
        a: null;
        isInvalid: boolean;
        currentSpotAreaID: string;
        currentSpotAreaName: string;
        changeFlag: boolean;
    };
    chargePosition: {
        x: null;
        y: null;
        a: null;
        changeFlag: boolean;
    };
    cleanSum_totalSquareMeters: number | null;
    cleanSum_totalSeconds: number | null;
    cleanSum_totalNumber: number | null;
    cleanLog: any[];
    cleanLog_lastImageUrl: any;
    cleanLog_lastTimestamp: number | null;
    cleanLog_lastTotalTime: number | null;
    cleanLog_lastTotalTimeString: string | null;
    cleanLog_lastSquareMeters: number | null;
    currentStats: {
        cleanedArea: null;
        cleanedSeconds: null;
        cleanType: null;
    };
    netInfoIP: string | null;
    netInfoWifiSSID: string | null;
    netInfoWifiSignal: number | null;
    netInfoMAC: string | null;
    firmwareVersion: any;
    timezone: string | null;
    OTA: Object | null;
    sysinfo: {
        load: any;
        uptime: any;
        signal: any;
        meminfo: any;
        pos: any;
    } | null;
    stationState: {
        type: number;
        state: number;
        isAirDrying: boolean;
        isSelfCleaning: boolean;
        isActive: boolean;
    } | null;
    stationInfo: {
        state: number | string;
        name: string;
        model: string;
        sn: string;
        wkVer: string;
    } | null;
    washInterval: number | null;
    washInfo: number | null;
    advancedMode: boolean | null;
    autoEmpty: any;
    autoEmptyStatus: any;
    cleanCount: number | null;
    cleanPreference: boolean | null;
    workMode: number | null;
    workState: {
        robot: any;
        station: any;
        paused: boolean;
    } | null;
    sweepMode: number | null;
    mopOnlyMode: boolean | null;
    borderSpin: boolean | null;
    borderSwitch: boolean | null;
    dusterRemind: {
        enabled: any;
        period: any;
    } | null;
    carpetPressure: boolean | null;
    carpetInfo: number | null;
    block: any;
    blockTime: {
        from: any;
        to: any;
    } | null;
    breakPoint: boolean | null;
    volume: number | null;
    voiceSimple: boolean | null;
    voiceAssistantState: boolean | null;
    trueDetect: any;
    avoidedObstacles: number;
    obstacleTypes: any;
    aiCleanItemState: {
        items: any;
        particleRemoval: boolean;
        petPoopPrevention: boolean;
    } | null;
    crossMapBorderWarning: boolean | null;
    cutDirection: number | null;
    moveupWarning: boolean | null;
    safeProtect: boolean | null;
    evt: {
        code: any;
        event: any;
    } | {
        code: any;
        event: string;
    } | null;
    currentTask: {
        type: string;
        triggerType: string;
        failed: boolean;
        stopReason: string;
    };
    liveLaunchPwdState: {
        state: any;
        hasPwd: any;
    } | null;
    airQuality: {
        particulateMatter25: any;
        particulateMatter10: any;
        airQualityIndex: any;
        volatileOrganicCompounds: any;
        temperature: any;
        humidity: any;
    } | null;
    aiBlockPlate: any;
    airbotAutoModel: {
        enable: any;
        trigger: any;
        aq: {
            aqStart: any;
            aqEnd: any;
        };
    } | null;
    angleFollow: boolean | null;
    angleWakeup: any;
    atmoLightIntensity: number | null;
    atmoVolume: number | null;
    areaPoint: Object | null;
    autonomousClean: boolean | null;
    bluetoothSpeaker: {
        enable: any;
        time: any;
        name: any;
    } | null;
    childLock: boolean | null;
    humanoidFollow: {
        video: any;
        yiko: any;
    } | null;
    mic: boolean | null;
    monitorAirState: boolean | null;
    threeModule: Object | null;
    threeModuleStatus: Object | null;
    dmodule: Object | null;
    efficiency: number | null;
    dryingDuration: number | null;
    airDryingStatus: string | null;
    relocationStatus: Object | null;
    relocationState: string | null;
    customizedScenarioCleaning: Object | null;
    errorCode: string;
    errorDescription: string;
    schedule: any[];
    /**
     * Handle the payload of the `CleanInfo` response/message
     * (e.g. charge status, clean status and the last area values)
     * @param {Object} payload
     */
    handleCleanInfo(payload: Object): void;
    /**
     * Handle the payload of the `StationState` response/message
     * @param {Object} payload
     */
    handleStationState(payload: Object): void;
    /**
     * Handle the payload of the `StationInfo` response/message
     * @param {Object} payload
     */
    handleStationInfo(payload: Object): void;
    /**
     * Handle the payload of the `WashInterval` response/message
     * @param {Object} payload
     */
    handleWashInterval(payload: Object): void;
    /**
     * Handle the payload of the `WashInfo` response/message
     * @param {Object} payload
     */
    handleWashInfo(payload: Object): void;
    /**
     * Handle the payload of the `Battery` response/message (battery level)
     * Parsing is delegated to `GetBatteryState.parse()` to ensure a single source
     * of truth shared with the `runAsync()` / `parseResponse()` path.
     * @param {Object} payload
     */
    handleBattery(payload: Object): void;
    /**
     * Handle the payload of the `Pos` response/message
     * (vacuum position and charger resp. charge position)
     * @param {Object} payload
     */
    handlePos(payload: Object): void;
    /**
     * TODO: Find out the value of the 'Evt' message
     * @param {Object} payload - The payload of the event.
     */
    handleEvt(payload: Object): void;
    /**
     * Handle the payload of the `Speed` response/message (vacuum power resp. suction power)
     * @param {Object} payload
     */
    handleSpeed(payload: Object): void;
    /**
     * Handle the payload of the `NetInfo` response/message
     * (network addresses and Wi-Fi status)
     * @param {Object} payload
     */
    handleNetInfo(payload: Object): void;
    /**
     * Handle the payload of the `BorderSwitch` response/message
     * @param {Object} payload
     */
    handleBorderSwitch(payload: Object): void;
    /**
     * Handle the payload of the `CrossMapBorderWarning` response/message
     * @param {Object} payload
     */
    handleCrossMapBorderWarning(payload: Object): void;
    /**
     * Handle the payload of the `CutDirection` response/message
     * @param {Object} payload
     */
    handleCutDirection(payload: Object): void;
    /**
     * Handle the payload of the `MoveupWarning` response/message
     * @param {Object} payload
     */
    handleMoveupWarning(payload: Object): void;
    /**
     * Handle the payload of the `SafeProtect` response/message
     * @param {Object} payload
     */
    handleSafeProtect(payload: Object): void;
    /**
     * Handle the payload of the `WorkState` response/message
     * @param {Object} payload
     */
    handleWorkState(payload: Object): void;
    /**
     * Handle the payload of the `WaterInfo` response/message
     * (water level and water box status)
     * @param {Object} payload
     */
    handleWaterInfo(payload: Object): void;
    /**
     * Handle the payload of the `AICleanItemState` response/message
     * Particle Removal and Pet Poop Avoidance mode (e.g. X1)
     * @param {Object} payload
     */
    handleAICleanItemState(payload: Object): void;
    /**
     * Handle the payload of the `AirDring` (sic) response/message (air drying status)
     * Seems to work for yeedi only
     * See `StationState` for Deebot models
     * @param {Object} payload
     */
    handleAirDryingState(payload: Object): void;
    /**
     * Handle the payload of the `DryingDuration` response/message
     * @param {Object} payload
     */
    handleDryingDuration(payload: Object): void;
    /**
     * Handle the payload of the `BorderSpin` response/message
     * @param {Object} payload
     */
    handleBorderSpin(payload: Object): void;
    /**
     * Handle the payload of the `WorkMode` response/message
     * ('Work Mode', 'Cleaning Mode')
     * vacuum and mop = 0
     * vacuum only = 1
     * mop only = 2
     * mop after vacuum = 3
     * @param {Object} payload
     */
    handleWorkMode(payload: Object): void;
    /**
     * Handle the payload of the `CustomAreaMode` response/message
     * `Mopping Mode`/`Cleaning efficiency` is taken from the `CustomAreaMode` message
     * not from the `SweepMode` message
     * @param {Object} payload
     */
    handleCustomAreaMode(payload: Object): void;
    /**
     * Handle the payload of the `SweepMode` response/message
     * "Mop-Only" is taken from the SweepMode message
     * @param {Object} payload
     */
    handleSweepMode(payload: Object): void;
    /**
     * Handle the payload of the `ChargeState` response/message (charge status)
     * @param {Object} payload
     */
    handleChargeState(payload: Object): void;
    /**
     * Handle the payload of the `Sleep` response/message (sleep status)
     * @param {Object} payload
     */
    handleSleepStatus(payload: Object): void;
    /**
     * Handle the payload of the `CleanLogs` response/message
     * @param {Object} payload
     */
    handleCleanLogs(payload: Object): void;
    /**
     * Emit all CleanLog-related events.
     * Consolidates the emit logic for both code paths
     * (MQTT response via `lg/log.do` and REST API via `dln/api/log/clean_result/list`)
     */
    emitCleanLogEvents(): void;
    /**
     * Handle the payload of the `TotalStats` response/message
     * @param {Object} payload
     */
    handleTotalStats(payload: Object): void;
    /**
     * Handle the payload of the `RelocationState` response/message
     * @param {Object} payload
     */
    handleRelocationState(payload: Object): void;
    /**
     * Handle the payload of the `Volume` response/message
     * @param {Object} payload
     */
    handleVolume(payload: Object): void;
    /**
     * Handle the payload of the `BreakPoint` response/message
     * @param {Object} payload
     */
    handleBreakPoint(payload: Object): void;
    /**
     * Handle the payload of the `Block` response/message
     * @param {Object} payload
     */
    handleBlock(payload: Object): void;
    /**
     * Handle the payload of the 'AutoEmpty' response/message
     * @param {Object} payload
     */
    handleAutoEmpty(payload: Object): void;
    /**
     * Handle the payload of the 'AdvancedMode' response/message
     * @param {Object} payload
     */
    handleAdvancedMode(payload: Object): void;
    /**
     * Handle the payload of the 'TrueDetect' response/message
     * @param {Object} payload
     */
    handleTrueDetect(payload: Object): void;
    handleRecognization(payload: any): void;
    /**
     * Handle the payload of the 'CleanCount' response/message
     * @param {Object} payload
     */
    handleCleanCount(payload: Object): void;
    /**
     * Handle the payload of the 'DusterRemind' response/message
     * @param {Object} payload
     */
    handleDusterRemind(payload: Object): void;
    /**
     * Handle the payload of the 'CarpertPressure' (sic) response/message
     * 'Auto-Boost Suction'
     * @param {Object} payload
     */
    handleCarpetPressure(payload: Object): void;
    /**
     * Handle the payload of the 'CarpetInfo' response/message
     * 'Carpet cleaning strategy'
     * @param {Object} payload
     */
    handleCarpetInfo(payload: Object): void;
    /**
     * Handle the payload of the `CleanPreference` response/message
     * @param {Object} payload
     */
    handleCleanPreference(payload: Object): void;
    /**
     * Handle the payload of the `LiveLaunchPwdState` response/message
     * @param {Object} payload
     */
    handleLiveLaunchPwdState(payload: Object): void;
    /**
     * Handle the payload of the `WiFiList` response/message
     * @param {Object} payload
     */
    handleWiFiList(payload: Object): void;
    /**
     * Handle the payload of the `OverTheAirUpdate` response/message
     * @param {Object} payload
     */
    handleOverTheAirUpdate(payload: Object): void;
    /**
     * Handle the payload of the `TimeZone` response/message
     * @param {Object} payload
     */
    handleTimeZone(payload: Object): void;
    /**
     * Handle the payload of the 'Stats' response/message
     * @param {Object} payload
     */
    handleStats(payload: Object): void;
    /**
     * Handle the payload of the 'Sched' response/message (Schedule)
     * @param {Object} payload
     */
    handleSched(payload: Object): void;
    /**
     * Handle the payload of the 'QuickCommand' response/message
     * @param {Object} payload - The payload containing the customized scenario cleaning.
     */
    handleQuickCommand(payload: Object): void;
    /**
     * Handle the payload of the 'Error' response/message
     * @param {Object} payload
     */
    handleResponseError(payload: Object): void;
    /**
     * Handles the air quality data received from the payload.
     * 'Indoor' Air Quality
     * @param {object} payload - The air quality data payload.
     */
    handleAirQuality(payload: object): void;
    /**
     * Handle the payload of the 'MonitorAirState' response/message
     * @param {Object} payload
     */
    handleMonitorAirState(payload: Object): void;
    /**
     * Handle the payload of the 'AngleFollow' response/message
     * 'Face to Me' option
     * @param {Object} payload
     */
    handleAngleFollow(payload: Object): void;
    /**
     * Handle the payload of the 'AngleWakeup' response/message
     * @param {Object} payload
     */
    handleAngleWakeup(payload: Object): void;
    /**
     * Handle the payload of the 'Mic' response/message
     * 'Microphone'
     * @param {Object} payload
     */
    handleMic(payload: Object): void;
    /**
     * Handle the payload of the 'VoiceSimple' response/message
     * 'Working Status Voice Report'
     * @param {Object} payload
     */
    handleVoiceSimple(payload: Object): void;
    /**
     * Handle the payload of the 'DrivingWheel' response/message
     * @param {Object} payload
     */
    handleDrivingWheel(payload: Object): void;
    drivingWheel: boolean | undefined;
    /**
     * Handle the payload of the 'ChildLock' response/message
     * 'Child Lock'
     * @param {Object} payload
     */
    handleChildLock(payload: Object): void;
    /**
     * Handle the payload of the 'VoiceAssistantState' response/message
     * 'YIKO Voice Assistant'
     * @param {Object} payload
     */
    handleVoiceAssistantState(payload: Object): void;
    /**
     * Handle the payload of the 'HumanoidFollow' response/message
     * 'Lab Features' => 'Follow Me'
     * @param {Object} payload
     */
    handleHumanoidFollow(payload: Object): void;
    /**
     * Handle the payload of the 'AutonomousClean' response/message
     * 'Self-linked Purification'
     * @param {Object} payload
     */
    handleAutonomousClean(payload: Object): void;
    /**
     * Handle the payload of the 'AirbotAutoMode' response/message
     * 'Linked Purification' (linked to Air Quality Monitor)
     * @param {Object} payload
     */
    handleAirbotAutoModel(payload: Object): void;
    /**
     * Handle the payload of the 'BlueSpeaker' response/message
     * 'Bluetooth Speaker'
     * @param {Object} payload
     */
    handleBlueSpeaker(payload: Object): void;
    /**
     * Handle the payload of the 'Efficiency' response/message
     * Always seems to return a value of 0
     * @param {Object} payload
     */
    handleEfficiency(payload: Object): void;
    /**
     * Handle the payload of the 'AtmoLight' response/message
     * 'Light Brightness'
     * @param {Object} payload
     */
    handleAtmoLight(payload: Object): void;
    /**
     * Handle the payload of the 'AtmoVolume' response/message
     * 'Volume'
     * @param {Object} payload
     */
    handleAtmoVolume(payload: Object): void;
    /**
     * Handle the payload of the 'ThreeModule' (UV, Humidifier, AirFreshener) response/message
     * It contains the current level set for Air Freshening and Humidification
     * @param {Object} payload
     */
    handleThreeModule(payload: Object): void;
    /**
     * Handle the payload of the 'ThreeModuleStatus' (UV, Humidifier, AirFreshener) response/message
     * It contains the working status of these modules
     * @param {Object} payload
     */
    handleThreeModuleStatus(payload: Object): void;
    /**
     * Handle the payload of the 'AreaPoint' response/message
     * @param {Object} payload
     */
    handleAreaPoint(payload: Object): void;
    /**
     * Handle the payload of the 'AiBlockPlate' response/message
     * @param {Object} payload
     */
    handleAiBlockPlate(payload: Object): void;
    /**
     * Handle the payload of the '(FwBuryPoint-)Sysinfo' response/message
     * @param {Object} payload
     */
    handleSysinfo(payload: Object): void;
    /**
     * Handle the payload/state of the current task.
     * @param {string} type - The type of task.
     * @param {Object} payload - The task payload.
     */
    handleTask(type: string, payload: Object): void;
    /**
     * Handle the payload of the `DModule` response/message
     * @param {Object} payload
     */
    handleDModule(payload: Object): void;
    /**
     * Get the correct command name for obstacle detection based on device platform type.
     * @returns {string}
     */
    getCmdForObstacleDetection(): string;
}
//# sourceMappingURL=botState.d.ts.map